import os
import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.safari.service import Service as SafariService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

# List of URLs to test
urls = [
    "https://www.getcalley.com/",
    "https://www.getcalley.com/calley-call-from-browser/",
    "https://www.getcalley.com/calley-pro-features/",
    "https://www.getcalley.com/best-auto-dialer-app/",
    "https://www.getcalley.com/how-calley-auto-dialer-app-works/"
]

# Devices and their resolutions
devices = {
    "Desktop": [(1920, 1080), (1366, 768), (1536, 864)],
    "Mobile": [(360, 640), (414, 896), (375, 667)]
}

def setup_browser(browser_type):
    if browser_type == 'chrome':
        service = ChromeService(ChromeDriverManager().install())
        browser = webdriver.Chrome(service=service)
    elif browser_type == 'firefox':
        service = FirefoxService(GeckoDriverManager().install())
        browser = webdriver.Firefox(service=service)
    elif browser_type == 'safari':
        service = SafariService()
        browser = webdriver.Safari(service=service)
    else:
        raise ValueError("Unsupported browser type!!")
    return browser

def take_screenshot(browser, device, resolution, url):
    folder_path = os.path.join(device, f"{resolution[0]}x{resolution[1]}")
    os.makedirs(folder_path, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    file_name = f"{timestamp}.png"
    browser.get(url)
    browser.set_window_size(*resolution)
    browser.save_screenshot(os.path.join(folder_path, file_name))

def main():
    for browser_type in ['chrome', 'firefox', 'safari']:
        browser = setup_browser(browser_type)
        try:
            for device, resolutions in devices.items():
                for resolution in resolutions:
                    for url in urls:
                        take_screenshot(browser, device, resolution, url)
        finally:
            browser.quit()

if __name__ == "__main__":
    main()



'''import os
import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

# List of URLs to test
urls = [
    "https://www.getcalley.com/",
    "https://www.getcalley.com/calley-call-from-browser/",
    "https://www.getcalley.com/calley-pro-features/",
    "https://www.getcalley.com/best-auto-dialer-app/",
    "https://www.getcalley.com/how-calley-auto-dialer-app-works/"
]

# Devices and their resolutions
devices = {
    "Desktop": [(1920, 1080), (1366, 768), (1536, 864)],
    "Mobile": [(360, 640), (414, 896), (375, 667)]
}

def setup_browser():
    service = Service(ChromeDriverManager().install())
    browser = webdriver.Chrome(service=service)
    return browser

def take_screenshot(browser, device, resolution, url):
    folder_path = os.path.join(device, f"{resolution[0]}x{resolution[1]}")
    os.makedirs(folder_path, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    file_name = f"{timestamp}.png"
    browser.get(url)
    browser.set_window_size(*resolution)
    browser.save_screenshot(os.path.join(folder_path, file_name))

def main():
    browser = setup_browser()
    try:
        for device, resolutions in devices.items():
            for resolution in resolutions:
                for url in urls:
                    take_screenshot(browser, device, resolution, url)
    finally:
        browser.quit()

if __name__ == "__main__":
    main()'''

