from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import NoSuchElementException

import time
import os

def setup_browser():
    # Setup ChromeDriver
    service = Service(ChromeDriverManager().install())
    browser = webdriver.Chrome(service=service)
    return browser

"""def login(browser, url, username, password):
    browser.get(url)
    time.sleep(5)
    time.sleep(5)
    browser.find_element(By.NAME, "Username").send_keys(username)
    time.sleep(5)
    time.sleep(5)
    browser.find_element(By.NAME, "password").send_keys(password)
    time.sleep(5)
    time.sleep(5)
    browser.find_element(By.NAME, "password").send_keys(Keys.ENTER)
    time.sleep(5)"""
def login(browser, url, username, password):
    browser.get(url)
    time.sleep(5)
    time.sleep(5)
    time.sleep(5)
    # Wait for page to load
    try:
        username_input = browser.find_element(By.NAME, "username")
        time.sleep(5)
    except NoSuchElementException:
        # If not found, try with a different selector
        username_input = browser.find_element(By.ID, "inputEmail")
    username_input.send_keys(username)
    time.sleep(5)

    # Similarly, locate the password input field and enter the password
    password_input = browser.find_element(By.NAME, "password")
    time.sleep(5)
    password_input.send_keys(password)

    # Submit the form
    password_input.send_keys(Keys.ENTER)
    time.sleep(5)
    time.sleep(5)
    time.sleep(5)


'''def upload_file(browser):
    # Navigate to the upload section
    browser.find_element(By.XPATH, "//a[text()='Orders']").click()
    time.sleep(5)
    browser.find_element(By.XPATH, "//a[text()='Add Bulk Orders']").click()
    time.sleep(5)
    time.sleep(5)
    # File upload
    browser.find_element(By.NAME, "import_file").send_keys(os.path.abspath("demo-data.xls"))
    time.sleep(5)
    time.sleep(5)
    browser.find_element(By.ID, "validateButton").click()'''

def upload_file(browser):
    # Navigate to the upload section
    try:
        order_link = browser.find_element(By.XPATH, "//a[contains(text(),'Order')]")
        order_link.click()
        time.sleep(5)
        orders_link = browser.find_element(By.XPATH, "//a[contains(text(),'Orders')]")
        orders_link.click()
        time.sleep(5)

    except NoSuchElementException:
        print("Orders link not found, waiting and retrying...")
        time.sleep(10)
        orders_link = browser.find_element(By.XPATH, "//a[contains(text(),'Orders')]")
        orders_link.click()

    time.sleep(5)
    bulk_orders_link = browser.find_element(By.XPATH, "//a[contains(text(),'Add Bulk Orders')]")
    bulk_orders_link.click()
    time.sleep(5)
    time.sleep(5)
    # File upload
    browser.find_element(By.NAME, "import_file").send_keys(os.path.abspath("demo-data.xls"))
    time.sleep(5)
    time.sleep(5)
    browser.find_element(By.ID, "validateButton").click()


def take_screenshot(browser):
    time.sleep(5)  # Wait for page to load and validations to complete
    time.sleep(5)
    time.sleep(5)
    time.sleep(5)
    screenshot_name = "final_output.png"
    browser.save_screenshot(screenshot_name)
    print(f"Screenshot saved as {screenshot_name}")

def main():
    browser = setup_browser()
    try:
        login(browser, "https://demo.dealsdray.com/", "prexo.mis@dealsdray.com", "prexo.mis@dealsdray.com")
        upload_file(browser)
        take_screenshot(browser)
    finally:
        browser.quit()

if __name__ == "__main__":
    main()
